-- AlterTable
ALTER TABLE `guess` MODIFY `guessResultPoints` INTEGER NOT NULL DEFAULT -1;
